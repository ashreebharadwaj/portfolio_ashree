# Personal Portfolio Website Requirements Document
\n## 1. Website Overview\n
### 1.1 Website Name
Ashree Bharadwaj - Personal Portfolio Website

### 1.2 Website Description
A fully responsive and interactive personal portfolio website showcasing biography, skills, experience & certifications, photo gallery, and contact information across five main pages with modern dark aesthetic and smooth animations.
\n### 1.3 Website Features
- **Home Page**: 
  - Hero section introducing 'Ashree Bharadwaj' with circular profile photo positioned next to intro text
  - Profile photo specifications: circular shape with 3px solid #00D9FF border, subtle glow shadow effect, hover scale animation
  - Use uploaded image 'WhatsApp Image 2025-11-28 at 10.02.45 PM.jpeg' as profile photo with option to replace
  - Smooth action buttons to About and Experience sections\n  - **Animated Sparkles Background**: Small neon teal glowing particles (#00D9FF) floating gently and randomly around the screen with soft animation, positioned behind all content (z-index below text and buttons), with slight glow trail on movement, optimized for smooth performance on mobile devices
\n- **About Me Page**: \n  - Circular profile photo positioned next to personal biography with same styling as Home page
  - Personal biography, skills badges, hobbies, and timeline-style achievements with hover scale effects on cards

- **Experience & Certifications Page**: 
  - Work Experience section with timeline layout showing roles, companies, and duration
  - Education section with academic qualifications and institutions
  - Certifications section displaying professional certificates with icons and issue dates
  - Skills progress bars or visual indicators for technical proficiencies
  - Interactive cards with hover effects and smooth animations

- **Gallery & Memories Page**:
  - Page title: 'Gallery & Memories'
  - Responsive photo grid layout displaying 12 images with smooth rounded corners
  - Each image includes a caption that appears with glow effect on hover
  - **Hover Effects**:
    - Smooth zoom-in animation on image\n    - Neon teal glow border with soft pulse effect
    - Glass blur overlay behind caption text
    - Subtle teal sparkle shimmer animation around images (small, soft-glowing, non-distracting particles)
  - **Lightbox Modal**: Click on any image to view full-size version in modal overlay with close button
  - **Upload/Replace Functionality**: Each image has upload/replace option (placeholder images initially)
  - Styled 'Back to Home' button with consistent design theme
  - Dark theme consistent with overall website (charcoal black background + neon teal accents)

- **Contact Me Page**: 
  - Contact form with name, email, and message fields
  - Form validation and email sending via EmailJS or Web3Forms
  - Social media icons (Instagram + LinkedIn)\n\n- **Photo Management**: Button functionality to allow replacement of profile photo

- **Navigation Bar**: \n  - Persistent navigation across all pages including new Gallery link
  - Active page highlighting and dark mode toggle icon (preference saved in localStorage)

- **Responsive Design**: Mobile-first approach optimized for mobile, tablet, and laptop devices

- **Interactive Elements**: 
  - Smooth scrolling with scroll reveal animations (fade/slide from bottom)
  - Loading fade-in animation on page load\n  - Back to Top floating button with smooth scroll\n  - Hover and ripple effects on buttons
  - Profile photo hover scale animation\n\n- **Footer**: Sticky footer at bottom with ©2025 'Ashree Bharadwaj'\n
## 2. Technical Requirements

### 2.1 Technology Stack
- HTML for page structure
- CSS for styling and responsive layout
- JavaScript for form validation, dark mode toggle, photo replacement functionality, sparkle animation, lightbox modal, and interactive features
- ScrollReveal library for scroll animations
- EmailJS or Web3Forms for form email sending
- Font Awesome or similar for icons

### 2.2 File Structure
- index.html (Home Page)
- about.html (About Me Page)
- experience.html (Experience & Certifications Page)\n- gallery.html (Gallery & Memories Page)
- contact.html (Contact Me Page)
- styles.css (Stylesheet)
- script.js (JavaScript functionality including sparkle animation and lightbox modal)
- WhatsApp Image 2025-11-28 at 10.02.45 PM.jpeg (Profile photo)

### 2.3 Form Validation & Email Sending
- Client-side validation using JavaScript for Contact form
- Required fields: Name, Email, Message
- Email format validation
- Email sending functionality via EmailJS or Web3Forms\n\n### 2.4 Photo Upload Functionality
- Button to trigger file input for photo replacement on profile photo
- Upload/replace button for each of the 12 gallery images
- JavaScript to handle image file selection and preview
- Local storage or temporary display of uploaded photos

### 2.5 Sparkle Animation Implementation
- **Home Page Sparkles**: JavaScript-based particle system generating small neon teal (#00D9FF) glowing particles with random floating animation, positioned with z-index below content layer, glow trail effect, performance optimized with limited particle count and requestAnimationFrame\n- **Gallery Page Sparkles**: Subtle teal sparkle shimmer animation around images on hover, small soft-glowing particles appearing near image borders, non-distracting and performance-optimized
\n### 2.6 Lightbox Modal Implementation
- JavaScript-based modal overlay triggered on image click
- Full-size image display with dark semi-transparent background
- Close button (X icon) in top-right corner
- Click outside image or press ESC key to close modal
- Smooth fade-in/fade-out transition

### 2.7 Meta Information
- Each page includes meta title and description tags
\n## 3. Design Style\n
### 3.1 Color Scheme
- Primary color: Neon teal (#00D9FF) for accents and highlights
- Background color: Charcoal/dark gray for modern dark aesthetic
- Text color: Light gray or white for contrast
- Accent colors: Bright teal for hover states and interactive elements
- Sparkle particles: Neon teal (#00D9FF) with glow effect

### 3.2 Typography
- Font family: Poppins or Montserrat\n- Clear hierarchy with varied font weights for headings and body text
\n### 3.3 Visual Details
- Circular profile photo with 3px solid #00D9FF border and subtle neon glow shadow
- Profile photo hover scale animation (scale 1.05)\n- Smooth rounded corners on cards, buttons, and gallery images
- Subtle shadow effects for depth on interactive elements
- Hover scale effects on cards (About page and Experience page)
- **Gallery Image Hover Effects**: Zoom-in animation, neon teal glow border with soft pulse, glass blur overlay behind caption, subtle sparkle shimmer around image edges
- Ripple effects on buttons\n- Smooth transitions and animations throughout
- Loading fade-in animation on page load\n- Scroll reveal animations (fade/slide from bottom)
- Animated sparkles on Home page and Gallery page hover states
\n### 3.4 Layout Approach
- Mobile-first responsive design with clean layout and consistent spacing
- Profile photo positioned next to intro text on Home and About pages with flexible layout for different screen sizes
- **Gallery Page Layout**: Responsive grid layout for 12 images (4 columns on desktop, 3 on tablet, 2 on mobile) with equal spacing and smooth rounded corners
- Grid-based layout for experience cards, certification badges, and content sections
- Timeline layout for work experience and education sections
- Responsive breakpoints for mobile (< 768px), tablet (768px - 1024px), and laptop (> 1024px)
- Fixed or sticky navigation bar for easy access with Gallery link added
- Sticky footer at bottom of all pages\n- Back to Top floating button for improved navigation
- Sparkle animation layer positioned behind all interactive elements with appropriate z-index stacking
- Lightbox modal centered on screen with overlay covering entire viewport