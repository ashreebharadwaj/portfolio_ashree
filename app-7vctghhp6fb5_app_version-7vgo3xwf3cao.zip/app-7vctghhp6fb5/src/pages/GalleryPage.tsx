import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface GalleryImage {
  id: number;
  src: string;
  caption: string;
}

const GalleryPage: React.FC = () => {
  const [images, setImages] = useState<GalleryImage[]>([
    { id: 1, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vg6yl4adtds.jpg", caption: "Dining Delights" },
    { id: 2, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vg6yl4ad43k.jpg", caption: "Sweet Moments" },
    { id: 3, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vg6yl4adzpc.jpg", caption: "Beach Vibes" },
    { id: 4, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vg6yl4adaf4.jpg", caption: "Food Adventures" },
    { id: 5, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vg6y5c1ghz5.jpg", caption: "Artistic Touch" },
    { id: 6, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vgcrqe86hvk.jpg", caption: "Sunset Serenity" },
    { id: 7, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vgcrqe87dhc.jpg", caption: "Seventeen Celebration" },
    { id: 8, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vgcrqe86o74.jpg", caption: "Luxury Retreat" },
    { id: 9, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vgcrqe86bk0.jpg", caption: "Matcha Moments" },
    { id: 10, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vgda5cm0r9c.jpg", caption: "Golden Hour" },
    { id: 11, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vggu6gt5t6o.jpg", caption: "Pasta Perfection" },
    { id: 12, src: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vggu6gt5zi8.jpg", caption: "Art in Progress" }
  ]);

  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  const handleImageUpload = (id: number, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImages(images.map(img => 
          img.id === id ? { ...img, src: reader.result as string } : img
        ));
      };
      reader.readAsDataURL(file);
    }
  };

  const openLightbox = (image: GalleryImage) => {
    setSelectedImage(image);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  return (
    <div className="min-h-screen py-12 px-4 xl:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-12 space-y-4">
          <h1 className="text-4xl xl:text-5xl font-bold">
            Gallery <span className="text-primary">&amp;</span> Memories
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            A collection of moments captured through my journey
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-12">
          {images.map((image) => (
            <div
              key={image.id}
              className="gallery-item-wrapper"
              onMouseEnter={() => setHoveredId(image.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              <div className="gallery-item relative group cursor-pointer overflow-hidden rounded-2xl aspect-[4/3]">
                {/* Sparkle shimmer effect on hover */}
                {hoveredId === image.id && (
                  <div className="gallery-sparkles">
                    {[...Array(8)].map((_, i) => (
                      <div key={i} className="gallery-sparkle" />
                    ))}
                  </div>
                )}

                {/* Image */}
                <img
                  src={image.src}
                  alt={image.caption}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  onClick={() => openLightbox(image)}
                />

                {/* Glass blur overlay with caption */}
                <div className="gallery-caption">
                  <p className="text-lg font-semibold text-white drop-shadow-lg">
                    {image.caption}
                  </p>
                </div>

                {/* Upload button */}
                <label
                  htmlFor={`upload-${image.id}`}
                  className="absolute top-3 right-3 bg-background/80 backdrop-blur-sm p-2 rounded-lg cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-primary hover:text-primary-foreground z-10"
                  onClick={(e) => e.stopPropagation()}
                >
                  <Upload className="w-4 h-4" />
                  <input
                    id={`upload-${image.id}`}
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageUpload(image.id, e)}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          ))}
        </div>

        {/* Back to Home Button */}
        <div className="flex justify-center">
          <Link to="/">
            <Button className="group">
              <ArrowLeft className="mr-2 h-4 w-4 transition-transform group-hover:-translate-x-1" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div
          className="lightbox-overlay"
          onClick={closeLightbox}
        >
          <div className="lightbox-content" onClick={(e) => e.stopPropagation()}>
            <button
              className="lightbox-close"
              onClick={closeLightbox}
              aria-label="Close lightbox"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={selectedImage.src}
              alt={selectedImage.caption}
              className="lightbox-image"
            />
            <div className="lightbox-caption">
              <p className="text-xl font-semibold">{selectedImage.caption}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GalleryPage;
