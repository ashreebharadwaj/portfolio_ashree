import React from "react";
import { GraduationCap, Calendar, MapPin, Award } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const ExperiencePage: React.FC = () => {
  const education = [
    {
      degree: "Bachelor of Technology in Computer Science",
      institution: "Fr. CRCE",
      location: "Mumbai, India",
      period: "2025 - 2029",
      description: "Currently pursuing my undergraduate degree in Computer Science Engineering. As a first-year student, I am building a strong foundation in programming fundamentals, data structures, and web development. Eager to learn and explore new technologies while developing practical skills through hands-on projects.",
      achievements: [
        "Part of the Student Council Committee",
        "Actively participating in college technical events",
        "Learning modern web development technologies",
        "Building personal projects to enhance coding skills"
      ]
    },
    {
      degree: "Higher Secondary Education (HSC)",
      institution: "Nirmala Memorial Foundation",
      location: "Mumbai, India",
      period: "2023 - 2025",
      description: "Completed Higher Secondary Education with focus on Science stream, specializing in Physics, Chemistry, and Mathematics. Developed strong analytical and problem-solving skills that laid the foundation for my engineering journey.",
      achievements: [
        "Successfully completed HSC with good academic performance",
        "Developed interest in computer science and programming",
        "Participated in school technical activities",
        "Built strong foundation in mathematics and logical thinking"
      ]
    }
  ];

  const certifications = [
    {
      name: "Responsive Web Design",
      issuer: "freeCodeCamp",
      date: "2023"
    },
    {
      name: "JavaScript Algorithms and Data Structures",
      issuer: "freeCodeCamp",
      date: "2023"
    },
    {
      name: "React - The Complete Guide",
      issuer: "Udemy",
      date: "2024"
    }
  ];

  return (
    <div className="min-h-screen py-12 px-4 xl:px-8">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Page Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl xl:text-5xl font-bold gradient-text">
            Education & Certifications
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            My academic journey and continuous learning path as I build my skills and passion for technology
          </p>
        </div>

        {/* Education Section */}
        <section className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <GraduationCap className="h-6 w-6 text-primary" />
            </div>
            <h2 className="text-3xl font-bold">Education</h2>
          </div>

          <div className="relative space-y-8">
            {/* Timeline Line */}
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-primary/20 hidden xl:block" />

            {education.map((edu, index) => (
              <div key={index} className="relative">
                {/* Timeline Dot */}
                <div className="absolute left-6 top-6 w-4 h-4 bg-primary rounded-full border-4 border-background shadow-[0_0_10px_rgba(0,217,255,0.5)] hidden xl:block transform -translate-x-1/2" />

                <Card className="xl:ml-16 border-2 hover:border-primary transition-all hover:shadow-lg">
                  <CardHeader>
                    <div className="flex flex-col xl:flex-row xl:items-start xl:justify-between gap-4">
                      <div className="space-y-2">
                        <CardTitle className="text-xl">{edu.degree}</CardTitle>
                        <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <GraduationCap className="h-4 w-4" />
                            <span>{edu.institution}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            <span>{edu.location}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            <span>{edu.period}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">{edu.description}</p>
                    <div className="space-y-2">
                      <h4 className="font-semibold flex items-center gap-2">
                        <Award className="h-4 w-4 text-primary" />
                        Key Highlights
                      </h4>
                      <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                        {edu.achievements.map((achievement, idx) => (
                          <li key={idx}>{achievement}</li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </section>

        {/* Certifications Section */}
        <section className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <Award className="h-6 w-6 text-primary" />
            </div>
            <h2 className="text-3xl font-bold">Certifications</h2>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {certifications.map((cert, index) => (
              <Card key={index} className="border-2 hover:border-primary transition-all hover:shadow-lg">
                <CardContent className="pt-6 space-y-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Award className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-lg">{cert.name}</h3>
                  <p className="text-sm text-muted-foreground">{cert.issuer}</p>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>{cert.date}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <Card className="bg-gradient-to-br from-primary/10 via-background to-accent/10 border-2 border-primary/20">
          <CardContent className="pt-6 text-center space-y-4">
            <h3 className="text-2xl font-bold">Let's Connect!</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              I'm eager to learn, collaborate on projects, and connect with fellow developers and tech enthusiasts. Feel free to reach out!
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ExperiencePage;
