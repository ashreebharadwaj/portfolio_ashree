import React, { useState } from "react";
import { Award, BookOpen, Code2, Heart, Lightbulb, Target, Upload } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const AboutPage: React.FC = () => {
  const [profileImage, setProfileImage] = useState<string>("https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vegbkoo42yo.jpg");

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const skills = [
    "React", "TypeScript", "JavaScript", "Node.js", "Python",
    "HTML/CSS", "Tailwind CSS", "Git", "REST APIs", "SQL",
    "UI/UX Design", "Responsive Design"
  ];

  const achievements = [
    {
      icon: Award,
      title: "Academic Excellence",
      description: "Consistently maintained high academic performance throughout my studies"
    },
    {
      icon: Code2,
      title: "Hackathon Participation",
      description: "Active participant in University Tech Challenge 2024"
    },
    {
      icon: Target,
      title: "Project Leadership",
      description: "Demonstrated good leadership qualities while leading the project"
    },
    {
      icon: Lightbulb,
      title: "Innovation Award",
      description: "Recognized for creative problem-solving approach"
    }
  ];

  const interests = [
    { icon: Code2, name: "Web Development", color: "bg-primary/10 text-primary" },
    { icon: BookOpen, name: "Continuous Learning", color: "bg-accent/50 text-accent-foreground" },
    { icon: Heart, name: "Open Source", color: "bg-primary/10 text-primary" },
    { icon: Lightbulb, name: "Problem Solving", color: "bg-accent/50 text-accent-foreground" }
  ];

  return (
    <div className="min-h-screen py-12 px-4 xl:px-8">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h1 className="text-4xl xl:text-6xl font-bold">
            About <span className="gradient-text">Me</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Get to know more about my journey, skills, and what drives me
          </p>
        </div>

        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col xl:flex-row gap-8 items-center xl:items-start">
              {/* Profile Photo */}
              <div className="relative group flex-shrink-0">
                <img
                  src={profileImage}
                  alt="Profile"
                  className="w-48 h-48 xl:w-64 xl:h-64 rounded-full object-cover border-[3px] border-primary shadow-[0_0_30px_rgba(0,217,255,0.4)] transition-all duration-300 group-hover:scale-105 group-hover:shadow-[0_0_40px_rgba(0,217,255,0.6)]"
                />
                <label
                  htmlFor="about-profile-upload"
                  className="absolute bottom-2 right-2 bg-primary text-primary-foreground p-2.5 rounded-full cursor-pointer shadow-lg hover:scale-110 transition-transform duration-300"
                >
                  <Upload className="w-4 h-4" />
                  <input
                    id="about-profile-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Story Content */}
              <div className="flex-1 space-y-4">
                <h2 className="text-2xl font-bold"></h2>
                <div className="space-y-4 text-muted-foreground">
                  <p>I am a creatively driven individual with a strong foundation in painting, coding, and singing—three disciplines that allow me to express ideas with both artistry and precision. Guided by a naturally curious mind, I am deeply fascinated by technological development and the evolving landscape of innovation. I thrive on exploring new concepts, learning continuously, and applying creativity to meaningful problem-solving. With a balanced blend of artistic vision and technical interest, I aim to contribute thoughtfully and confidently to every project I undertake.</p>
                  <p></p>
                  <p>
                    When I'm not coding, you'll find me exploring new technologies, contributing 
                    to open-source projects, or sharing knowledge with fellow developers. I'm 
                    always eager to learn, grow, and take on new challenges.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-3xl font-bold mb-6 text-center">
            My <span className="gradient-text">Interests</span>
          </h2>
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
            {interests.map((interest, index) => (
              <Card key={index} className="hover:shadow-lg transition-all">
                <CardContent className="pt-6 text-center space-y-3">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center mx-auto ${interest.color}`}>
                    <interest.icon className="h-6 w-6" />
                  </div>
                  <p className="font-medium">{interest.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-3xl font-bold mb-6 text-center">
            Technical <span className="gradient-text">Skills</span>
          </h2>
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-wrap gap-2 justify-center">
                {skills.map((skill, index) => (
                  <Badge 
                    key={index} 
                    variant="secondary" 
                    className="px-4 py-2 text-sm hover:bg-primary hover:text-primary-foreground transition-all cursor-default"
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <h2 className="text-3xl font-bold mb-6 text-center">
            Key <span className="gradient-text">Achievements</span>
          </h2>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {achievements.map((achievement, index) => (
              <Card key={index} className="hover:shadow-lg transition-all">
                <CardContent className="pt-6 flex gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <achievement.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-semibold text-lg">{achievement.title}</h3>
                    <p className="text-muted-foreground">{achievement.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
