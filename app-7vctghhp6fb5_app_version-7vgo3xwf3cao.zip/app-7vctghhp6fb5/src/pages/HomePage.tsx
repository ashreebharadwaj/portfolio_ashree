import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Code, Palette, Rocket, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Sparkles from "@/components/effects/Sparkles";

const HomePage: React.FC = () => {
  const [profileImage, setProfileImage] = useState<string>("https://miaoda-conversation-file.s3cdn.medo.dev/user-7vbsxz4f7thc/conv-7vctghhp6fb4/20251129/file-7vegbkoo42yo.jpg");

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Sparkles Background Effect */}
      <Sparkles />
      
      <section className="relative min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 xl:px-8 overflow-hidden z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10 -z-10" />
        
        <div className="relative max-w-7xl mx-auto w-full z-10">
          <div className="flex flex-col xl:flex-row items-center justify-center gap-12 xl:gap-16">
            {/* Profile Photo Section */}
            <div className="relative group">
              <div className="relative">
                <img
                  src={profileImage}
                  alt="Profile"
                  className="w-64 h-64 xl:w-80 xl:h-80 rounded-full object-cover border-[3px] border-primary shadow-[0_0_30px_rgba(0,217,255,0.4)] transition-all duration-300 group-hover:scale-105 group-hover:shadow-[0_0_40px_rgba(0,217,255,0.6)]"
                />
                <label
                  htmlFor="profile-upload"
                  className="absolute bottom-4 right-4 bg-primary text-primary-foreground p-3 rounded-full cursor-pointer shadow-lg hover:scale-110 transition-transform duration-300"
                >
                  <Upload className="w-5 h-5" />
                  <input
                    id="profile-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* Text Content Section */}
            <div className="flex-1 text-center xl:text-left space-y-8 max-w-2xl">
              <div className="space-y-4">
                <h1 className="text-4xl xl:text-7xl font-bold tracking-tight text-foreground">
                  Welcome to
                  <span className="block gradient-text">MY WORLD</span>
                </h1>
                <p className="text-lg xl:text-xl text-muted-foreground">Bringing together code, design, and curiosity — that’s how I create</p>
              </div>

              <div className="flex flex-col xl:flex-row gap-4 justify-center xl:justify-start items-center">
                <Button asChild size="lg" className="group">
                  <Link to="/about">
                    Get To Know Me
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
                <Button asChild size="lg">
                  <Link to="/experience">
                    View Experience
                  </Link>
                </Button>
              </div>
            </div>
          </div>

          {/* Feature Cards */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mt-24 max-w-5xl mx-auto">
            <Card className="border-2 hover:border-primary transition-all hover:shadow-lg">
              <CardContent className="pt-6 text-center space-y-3">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                  <Code className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold">Development</h3>
                <p className="text-muted-foreground">
                  Building robust and scalable applications with modern technologies
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary transition-all hover:shadow-lg">
              <CardContent className="pt-6 text-center space-y-3">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                  <Palette className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold">Design</h3>
                <p className="text-muted-foreground">
                  Creating beautiful and intuitive user interfaces that delight users
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary transition-all hover:shadow-lg">
              <CardContent className="pt-6 text-center space-y-3">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                  <Rocket className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold">Innovation</h3>
                <p className="text-muted-foreground">
                  Pushing boundaries and exploring new possibilities in tech
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
