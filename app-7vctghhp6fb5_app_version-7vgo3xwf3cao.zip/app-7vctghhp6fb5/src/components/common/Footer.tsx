import React from "react";
import { Github, Linkedin, Mail, Instagram } from "lucide-react";

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-muted border-t border-border">
      <div className="max-w-7xl mx-auto py-12 px-4 xl:px-8">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4 gradient-text">
              About
            </h3>
            <p className="text-muted-foreground">
              A passionate developer creating amazing digital experiences. 
              Always learning, always building.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 gradient-text">
              Quick Links
            </h3>
            <div className="space-y-2 text-muted-foreground">
              <p>Home</p>
              <p>About Me</p>
              <p>Gallery</p>
              <p>Contact</p>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 gradient-text">
              Connect
            </h3>
            <div className="flex space-x-4">
              <a
                href="https://github.com/ashreebharadwaj"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-background hover:bg-accent transition-all"
                aria-label="GitHub"
              >
                <Github size={20} />
              </a>
              <a
                href="https://www.linkedin.com/in/ashree-b-a43b33385"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-background hover:bg-accent transition-all"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
              <a
                href="https://www.instagram.com/ashreebharadwaj?igsh=MWQzdHlmMWhkcDFpeg=="
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-background hover:bg-accent transition-all"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a
                href="mailto:bharadwajashree@gmail.com"
                className="p-2 rounded-lg bg-background hover:bg-accent transition-all"
                aria-label="Email"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border text-center text-muted-foreground">
          <p>{currentYear} Portfolio</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
