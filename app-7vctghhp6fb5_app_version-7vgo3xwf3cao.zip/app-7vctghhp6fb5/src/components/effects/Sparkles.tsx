import React, { useEffect, useState } from "react";

interface Sparkle {
  id: number;
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
}

const Sparkles: React.FC = () => {
  const [sparkles, setSparkles] = useState<Sparkle[]>([]);

  useEffect(() => {
    // Generate sparkles with random positions and properties
    const generateSparkles = () => {
      const newSparkles: Sparkle[] = [];
      const sparkleCount = window.innerWidth < 768 ? 15 : 25; // Fewer on mobile for performance

      for (let i = 0; i < sparkleCount; i++) {
        newSparkles.push({
          id: i,
          x: Math.random() * 100, // Random x position (percentage)
          y: Math.random() * 100, // Random y position (percentage)
          size: Math.random() * 3 + 2, // Size between 2-5px
          duration: Math.random() * 10 + 15, // Duration between 15-25s
          delay: Math.random() * 5, // Delay between 0-5s
        });
      }

      setSparkles(newSparkles);
    };

    generateSparkles();

    // Regenerate on window resize
    const handleResize = () => {
      generateSparkles();
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div className="sparkles-container">
      {sparkles.map((sparkle) => (
        <div
          key={sparkle.id}
          className="sparkle"
          style={{
            left: `${sparkle.x}%`,
            top: `${sparkle.y}%`,
            width: `${sparkle.size}px`,
            height: `${sparkle.size}px`,
            animationDuration: `${sparkle.duration}s`,
            animationDelay: `${sparkle.delay}s`,
          }}
        />
      ))}
    </div>
  );
};

export default Sparkles;
