# Welcome to Your Miaoda Project
Miaoda Application Link URL
    URL:https://medo.dev/projects/app-7vctghhp6fb5

# Ashree Bharadwaj - Personal Portfolio Website

A modern, fully responsive personal portfolio website featuring a dark aesthetic with neon teal and charcoal colors. Built with pure HTML, CSS, and JavaScript.

## 🌟 Features

### Design & Theme
- **Modern Dark Aesthetic**: Neon teal (#00D9FF) and charcoal color scheme
- **Dark/Light Mode Toggle**: Automatic theme preference saving in localStorage
- **Smooth Animations**: ScrollReveal animations with fade and slide effects
- **Responsive Design**: Mobile-first approach with seamless adaptation to all screen sizes
- **Interactive Elements**: Hover effects, ripple effects, and smooth transitions

### Pages
1. **Home Page**
   - Hero section with animated introduction
   - Statistics showcase
   - Feature cards highlighting skills
   - Smooth navigation to other sections

2. **About Me Page**
   - Personal biography
   - Technical skills with interactive badges
   - Hobbies and interests
   - Timeline-style achievements section

3. **Gallery/Portfolio Page**
   - Featured projects section with 3 main projects:
     - Smart Stick for Visually Impaired
     - Online Voting System
     - Portfolio Website
   - Interactive image carousel (Swiper.js) for memories
   - Project cards with hover effects and overlay links

4. **Contact Page**
   - Contact form with real-time validation
   - Email integration ready (Web3Forms/EmailJS)
   - Social media links (Instagram, LinkedIn)
   - Contact information display

### Functionality
- **Smooth Scrolling**: Enhanced navigation experience
- **Back to Top Button**: Floating button with smooth scroll
- **Mobile Menu**: Responsive hamburger menu for mobile devices
- **Form Validation**: Client-side validation with error messages
- **Loading Animation**: Page load fade-in effect
- **Keyboard Navigation**: Full keyboard accessibility support

## 🚀 Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)
- A text editor (VS Code, Sublime Text, etc.)
- Optional: Local web server for testing

### Installation

1. **Download the files**
   - All files are in the `/public/portfolio/` directory
   - Files included:
     - `index.html` - Home page
     - `about.html` - About Me page
     - `gallery.html` - Gallery/Portfolio page
     - `contact.html` - Contact page
     - `styles.css` - Main stylesheet
     - `script.js` - JavaScript functionality

2. **Open in browser**
   - Simply open `index.html` in your web browser
   - Or use a local server for better performance

3. **Customize**
   - Update personal information in HTML files
   - Replace social media links
   - Add your own project images
   - Customize colors in CSS variables

## 📧 Email Integration Setup

The contact form is ready to integrate with email services. Choose one:

### Option 1: Web3Forms (Recommended)
1. Visit [web3forms.com](https://web3forms.com)
2. Get your free access key
3. In `script.js`, replace `YOUR_WEB3FORMS_ACCESS_KEY` with your actual key
4. Uncomment the fetch code in the form submission handler

### Option 2: EmailJS
1. Sign up at [emailjs.com](https://www.emailjs.com)
2. Create an email service and template
3. Add EmailJS SDK to `contact.html`
4. Update the form submission code in `script.js`

## 🎨 Customization

### Colors
Edit CSS variables in `styles.css`:
```css
:root {
  --primary-color: #00d9ff;      /* Main accent color */
  --primary-dark: #00b8d4;       /* Darker shade */
  --primary-light: #4de8ff;      /* Lighter shade */
  --bg-dark: #0f0f0f;            /* Background */
  --bg-card: #1e1e1e;            /* Card background */
  /* ... more variables */
}
```

### Content
- **Personal Info**: Update name, bio, and descriptions in HTML files
- **Projects**: Modify project cards in `gallery.html`
- **Skills**: Edit skill badges in `about.html`
- **Social Links**: Update URLs in footer and contact page

### Images
- Replace image URLs in `gallery.html` with your own
- Update project screenshots
- Add more carousel slides in the memories section

## 📱 Responsive Breakpoints

- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

## 🔧 Technologies Used

- **HTML5**: Semantic markup
- **CSS3**: Modern styling with CSS Grid and Flexbox
- **JavaScript (ES6+)**: Interactive functionality
- **Font Awesome 6.4.0**: Icons
- **Google Fonts (Poppins)**: Typography
- **ScrollReveal 4.0.9**: Scroll animations
- **Swiper.js 11**: Image carousel
- **Web3Forms**: Contact form submission (optional)

## 🌐 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Opera (latest)

## 📄 File Structure

```
portfolio/
├── index.html          # Home page
├── about.html          # About Me page
├── gallery.html        # Gallery/Portfolio page
├── contact.html        # Contact page
├── styles.css          # Main stylesheet
├── script.js           # JavaScript functionality
└── README.md           # Documentation
```

## ✨ Features Checklist

- ✅ Fully responsive design
- ✅ Dark/Light mode toggle
- ✅ Smooth scroll animations
- ✅ Interactive navigation
- ✅ Form validation
- ✅ Image carousel
- ✅ Back to top button
- ✅ Mobile menu
- ✅ Hover effects
- ✅ Ripple effects
- ✅ Loading animation
- ✅ Keyboard navigation
- ✅ SEO-friendly meta tags
- ✅ Accessibility features

## 🎯 Performance

- Optimized CSS and JavaScript
- Lazy loading for images
- Minimal external dependencies
- Fast page load times
- Smooth animations (60fps)

## 📝 License

This project is open source and available for personal and commercial use.

## 🤝 Credits

- **Design & Development**: Ashree Bharadwaj
- **Icons**: Font Awesome
- **Fonts**: Google Fonts (Poppins)
- **Animations**: ScrollReveal
- **Carousel**: Swiper.js

## 📞 Support

For questions or issues, please contact through the contact form on the website or reach out via social media.

---

**Built with ❤️ by Ashree Bharadwaj**
