// ===== Page Loader =====
window.addEventListener('load', () => {
  const loader = document.querySelector('.page-loader');
  setTimeout(() => {
    loader.classList.add('hidden');
  }, 500);
});

// ===== Dark Mode Toggle =====
const themeToggle = document.getElementById('themeToggle');
const body = document.body;

// Check for saved theme preference or default to dark mode
const currentTheme = localStorage.getItem('theme') || 'dark';
if (currentTheme === 'light') {
  body.classList.add('light-mode');
  themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
} else {
  // Ensure dark mode is active by default
  body.classList.remove('light-mode');
  themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
  localStorage.setItem('theme', 'dark');
}

themeToggle.addEventListener('click', () => {
  body.classList.toggle('light-mode');
  
  // Update icon
  if (body.classList.contains('light-mode')) {
    themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    localStorage.setItem('theme', 'light');
  } else {
    themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    localStorage.setItem('theme', 'dark');
  }
});

// ===== Mobile Menu Toggle =====
const mobileMenuToggle = document.getElementById('mobileMenuToggle');
const navMenu = document.querySelector('.nav-menu');

mobileMenuToggle.addEventListener('click', () => {
  navMenu.classList.toggle('active');
  
  // Update icon
  const icon = mobileMenuToggle.querySelector('i');
  if (navMenu.classList.contains('active')) {
    icon.classList.remove('fa-bars');
    icon.classList.add('fa-times');
  } else {
    icon.classList.remove('fa-times');
    icon.classList.add('fa-bars');
  }
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    navMenu.classList.remove('active');
    const icon = mobileMenuToggle.querySelector('i');
    icon.classList.remove('fa-times');
    icon.classList.add('fa-bars');
  });
});

// Close mobile menu when clicking outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('.nav-container')) {
    navMenu.classList.remove('active');
    const icon = mobileMenuToggle.querySelector('i');
    icon.classList.remove('fa-times');
    icon.classList.add('fa-bars');
  }
});

// ===== Smooth Scrolling =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

// ===== Back to Top Button =====
const backToTop = document.getElementById('backToTop');

window.addEventListener('scroll', () => {
  if (window.pageYOffset > 300) {
    backToTop.classList.add('visible');
  } else {
    backToTop.classList.remove('visible');
  }
});

backToTop.addEventListener('click', () => {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
});

// ===== ScrollReveal Animations =====
if (typeof ScrollReveal !== 'undefined') {
  const sr = ScrollReveal({
    origin: 'bottom',
    distance: '60px',
    duration: 1000,
    delay: 200,
    reset: false
  });

  // Reveal elements with fade-up animation
  sr.reveal('.reveal-fade-up', {
    interval: 200
  });

  // Reveal feature cards
  sr.reveal('.feature-card', {
    interval: 150
  });

  // Reveal project cards
  sr.reveal('.project-card', {
    interval: 150
  });

  // Reveal timeline items
  sr.reveal('.timeline-item', {
    interval: 200,
    origin: 'left'
  });

  // Reveal skill badges
  sr.reveal('.skill-badge', {
    interval: 100
  });

  // Reveal hobby cards
  sr.reveal('.hobby-card', {
    interval: 150
  });
}

// ===== Swiper Slider (Gallery Page) =====
if (typeof Swiper !== 'undefined' && document.querySelector('.memories-slider')) {
  const swiper = new Swiper('.memories-slider', {
    loop: true,
    autoplay: {
      delay: 4000,
      disableOnInteraction: false,
    },
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    effect: 'slide',
    speed: 800,
    grabCursor: true,
  });
}

// ===== Contact Form Validation & Submission =====
const contactForm = document.getElementById('contactForm');

if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Clear previous errors
    document.querySelectorAll('.error-message').forEach(error => {
      error.textContent = '';
    });

    // Get form values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();

    // Validation flags
    let isValid = true;

    // Name validation
    if (name === '') {
      document.getElementById('nameError').textContent = 'Name is required';
      isValid = false;
    } else if (name.length < 2) {
      document.getElementById('nameError').textContent = 'Name must be at least 2 characters';
      isValid = false;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === '') {
      document.getElementById('emailError').textContent = 'Email is required';
      isValid = false;
    } else if (!emailRegex.test(email)) {
      document.getElementById('emailError').textContent = 'Please enter a valid email address';
      isValid = false;
    }

    // Message validation
    if (message === '') {
      document.getElementById('messageError').textContent = 'Message is required';
      isValid = false;
    } else if (message.length < 10) {
      document.getElementById('messageError').textContent = 'Message must be at least 10 characters';
      isValid = false;
    }

    // If validation passes, submit the form
    if (isValid) {
      const submitButton = contactForm.querySelector('button[type="submit"]');
      const originalButtonText = submitButton.innerHTML;
      
      // Disable button and show loading state
      submitButton.disabled = true;
      submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Sending...</span>';

      try {
        // Using Web3Forms API (you can replace with EmailJS or your own backend)
        // For Web3Forms, you need to get an access key from https://web3forms.com
        const formData = new FormData();
        formData.append('access_key', 'YOUR_WEB3FORMS_ACCESS_KEY'); // Replace with your actual key
        formData.append('name', name);
        formData.append('email', email);
        formData.append('message', message);
        formData.append('subject', 'New Contact Form Submission from Portfolio');

        // Simulate form submission (remove this and uncomment the fetch below when you have an API key)
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Uncomment this when you have a valid Web3Forms access key:
        /*
        const response = await fetch('https://api.web3forms.com/submit', {
          method: 'POST',
          body: formData
        });

        const data = await response.json();

        if (data.success) {
          showFormStatus('success', 'Message sent successfully! I\'ll get back to you soon.');
          contactForm.reset();
        } else {
          throw new Error('Form submission failed');
        }
        */

        // For demo purposes (remove when using real API):
        showFormStatus('success', 'Message sent successfully! I\'ll get back to you soon.');
        contactForm.reset();

      } catch (error) {
        showFormStatus('error', 'Oops! Something went wrong. Please try again later.');
        console.error('Form submission error:', error);
      } finally {
        // Re-enable button
        submitButton.disabled = false;
        submitButton.innerHTML = originalButtonText;
      }
    }
  });

  // Helper function to show form status
  function showFormStatus(type, message) {
    const formStatus = document.getElementById('formStatus');
    formStatus.className = `form-status ${type}`;
    formStatus.textContent = message;

    // Hide status after 5 seconds
    setTimeout(() => {
      formStatus.className = 'form-status';
      formStatus.textContent = '';
    }, 5000);
  }

  // Real-time validation feedback
  const nameInput = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const messageInput = document.getElementById('message');

  if (nameInput) {
    nameInput.addEventListener('blur', () => {
      const value = nameInput.value.trim();
      if (value === '') {
        document.getElementById('nameError').textContent = 'Name is required';
      } else if (value.length < 2) {
        document.getElementById('nameError').textContent = 'Name must be at least 2 characters';
      } else {
        document.getElementById('nameError').textContent = '';
      }
    });
  }

  if (emailInput) {
    emailInput.addEventListener('blur', () => {
      const value = emailInput.value.trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (value === '') {
        document.getElementById('emailError').textContent = 'Email is required';
      } else if (!emailRegex.test(value)) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address';
      } else {
        document.getElementById('emailError').textContent = '';
      }
    });
  }

  if (messageInput) {
    messageInput.addEventListener('blur', () => {
      const value = messageInput.value.trim();
      if (value === '') {
        document.getElementById('messageError').textContent = 'Message is required';
      } else if (value.length < 10) {
        document.getElementById('messageError').textContent = 'Message must be at least 10 characters';
      } else {
        document.getElementById('messageError').textContent = '';
      }
    });
  }
}

// ===== Ripple Effect Enhancement =====
document.querySelectorAll('.ripple').forEach(button => {
  button.addEventListener('click', function(e) {
    const ripple = document.createElement('span');
    const rect = this.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;

    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.classList.add('ripple-effect');

    this.appendChild(ripple);

    setTimeout(() => {
      ripple.remove();
    }, 600);
  });
});

// ===== Navbar Scroll Effect =====
let lastScroll = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
  const currentScroll = window.pageYOffset;

  if (currentScroll <= 0) {
    navbar.style.boxShadow = 'none';
  } else {
    navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.3)';
  }

  lastScroll = currentScroll;
});

// ===== Active Navigation Link Highlighting =====
function setActiveNavLink() {
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.remove('active');
    const linkPage = link.getAttribute('href');
    
    if (linkPage === currentPage || 
        (currentPage === '' && linkPage === 'index.html') ||
        (currentPage === 'index.html' && linkPage === 'index.html')) {
      link.classList.add('active');
    }
  });
}

// Set active link on page load
setActiveNavLink();

// ===== Typing Effect for Hero Title (Optional Enhancement) =====
const heroTitle = document.querySelector('.hero-title');
if (heroTitle && heroTitle.textContent.includes('Ashree Bharadwaj')) {
  // This is optional - you can enable it if you want a typing effect
  // Uncomment the code below to enable typing animation
  /*
  const text = heroTitle.innerHTML;
  heroTitle.innerHTML = '';
  let i = 0;
  
  function typeWriter() {
    if (i < text.length) {
      heroTitle.innerHTML += text.charAt(i);
      i++;
      setTimeout(typeWriter, 50);
    }
  }
  
  setTimeout(typeWriter, 500);
  */
}

// ===== Console Welcome Message =====
console.log('%c👋 Welcome to Ashree Bharadwaj\'s Portfolio!', 'color: #00d9ff; font-size: 20px; font-weight: bold;');
console.log('%cBuilt with ❤️ using HTML, CSS, and JavaScript', 'color: #b0b0b0; font-size: 14px;');

// ===== Prevent Form Resubmission on Page Refresh =====
if (window.history.replaceState) {
  window.history.replaceState(null, null, window.location.href);
}

// ===== Add Loading Animation to Images =====
document.querySelectorAll('img').forEach(img => {
  img.addEventListener('load', function() {
    this.style.opacity = '0';
    this.style.transition = 'opacity 0.5s ease';
    setTimeout(() => {
      this.style.opacity = '1';
    }, 100);
  });
});

// ===== Intersection Observer for Animations =====
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, observerOptions);

// Observe all elements with reveal classes
document.querySelectorAll('.reveal-fade-up').forEach(el => {
  observer.observe(el);
});

// ===== Performance: Lazy Loading for Images =====
if ('loading' in HTMLImageElement.prototype) {
  const images = document.querySelectorAll('img[loading="lazy"]');
  images.forEach(img => {
    img.src = img.dataset.src;
  });
} else {
  // Fallback for browsers that don't support lazy loading
  const script = document.createElement('script');
  script.src = 'https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.3.2/lazysizes.min.js';
  document.body.appendChild(script);
}

// ===== Add Keyboard Navigation Support =====
document.addEventListener('keydown', (e) => {
  // Press 'Escape' to close mobile menu
  if (e.key === 'Escape' && navMenu.classList.contains('active')) {
    navMenu.classList.remove('active');
    const icon = mobileMenuToggle.querySelector('i');
    icon.classList.remove('fa-times');
    icon.classList.add('fa-bars');
  }

  // Press 'Home' to scroll to top
  if (e.key === 'Home' && e.ctrlKey) {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
});

// ===== Accessibility: Focus Visible =====
document.addEventListener('keydown', (e) => {
  if (e.key === 'Tab') {
    document.body.classList.add('keyboard-nav');
  }
});

document.addEventListener('mousedown', () => {
  document.body.classList.remove('keyboard-nav');
});

// ===== Print Styles Handler =====
window.addEventListener('beforeprint', () => {
  document.body.classList.add('printing');
});

window.addEventListener('afterprint', () => {
  document.body.classList.remove('printing');
});
